// var head = document.querySelector('head');
// var html = document.querySelector('html');
// if(head == null){
//     head = document.createElement('head');
// }
// head.innerHTML+='<meta http-equiv="Content-type" content="text/html;charset=UTF-8">';
// html.appendChild(head);
var btn1 = document.createElement("button");
var sidebar = document.createElement("div");
sidebar.setAttribute("id", "mySidenav");
sidebar.setAttribute("class", "webber_sidenav");
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    //document.getElementById("main").style.marginLeft= "0";
}
sidebar.innerHTML = '<p><a href="javascript:void(0)" class="closebtn">&times;</a>  <a id="hashtag"></a> </p> <div id = "webber_comments"><a href="#"></a><a href="#"></a> <a href="#"></a><a href="#"></a></div><span id="adding"><input type="text" id="userinput" placeholder="" name="comment"><input type="submit" id="addingsubmit" value="Send"> </span>'

//
btn1.setAttribute("id", "webber_btn1");

btn1.innerHTML = "<";
document.body.appendChild(btn1);
document.body.appendChild(sidebar);

btn1.addEventListener('click',function () {
    "use strict";
    document.getElementById("mySidenav").style.width = "250px";
   // document.getElementById("main").style.marginRight = "250px";
    chrome.runtime.sendMessage({greeting: "load"}, function(response) {
        console.log(response.farewell);
        return 0;
    });
});
chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {

        if (request.greeting == "iconclicked"){
            alert("ahhh");
            document.getElementById("mySidenav").style.width = "250px";

            return 0;

        }
    });
var cls = document.querySelector('.closebtn');
cls.addEventListener('click',function () {
    "use strict";
    document.getElementById("mySidenav").style.width = "0";
})

var words="";
var doc={};
chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        console.log(sender.tab ?
            "from a content script:" + sender.tab.url :
            "from the extension");
        console.log(request.items,request.doc);

        if (request.greeting == "hello"){

            sendResponse({farewell: "goodbye"});

            var comment = request.items;
            var comment_str ="";
            if(comment.length==0){
                document.querySelector('#webber_comments').innerHTML = "Wanna say something here?";
                doc = request.doc;
            }else {
                var ht = document.querySelector('#hashtag');
                ht.innerHTML="";
                comment.forEach(x=>{
                    comment_str+=x;
                })
                document.querySelector('#webber_comments').innerHTML = comment_str;

                doc = request.doc;
                changelikes('.fa-thumbs-o-up');
                var oldcomments = document.querySelectorAll('.oldcomments');
                oldcomments.forEach(x=>{
                    "use strict";
                    words+= " "+x.innerHTML;
                });

                var keywords = keyword(words);
                console.log("keywords",keywords)
                keywords.forEach(x=>{
                    "use strict";
                        ht.innerHTML+="#"+x+" ";
                    }
                )
                return 0;
            }

        }
    });


var add =  document.getElementById("addingsubmit");
add.addEventListener('click',function () {
   // doc.comment = "will be something.innnerhtml";
    if(document.getElementById('userinput').value!=""){
    doc.comment = document.getElementById('userinput').value;
    if(document.querySelector('#webber_comments').innerHTML == "Wanna say something here?"){
        document.querySelector('#webber_comments').innerHTML = "";
    }
    document.querySelector('#webber_comments').innerHTML = "<li >" +"<p class='datetime'>"+((new Date()).toLocaleString()).slice(11)+ "</p>"+document.getElementById('userinput').value+document.querySelector('#webber_comments').innerHTML;

    $.ajax({
        //LQhi2n6DVD-gMbFM_4u1-ipfhbZZEqAx
        url: "https://api.mongolab.com/api/1/databases/webber/collections/boom?apiKey=KD1Ze8lriyElaVZNrfmIMwXwicLRCcUr",
        type: "POST",
        data: JSON.stringify( doc ),
        //data: object,
        contentType: "application/json"
    }).done(function( msg ) {
        console.log("ajax post",msg,JSON.stringify( doc ));
    });
    document.getElementById('userinput').value = "";
    }
});
//.fa-thumbs-o-up
function changelikes(likeordislike) {
    console.log('changelikes');
    var likes = document.querySelectorAll(likeordislike);
    likes.forEach(x=>{
        "use strict";
        x.addEventListener('click',function () {
            console.log("clicking")
            $.ajax({
                //LQhi2n6DVD-gMbFM_4u1-ipfhbZZEqAx
                url: "localhost:8080/changelikes",
                type: "POST",
                data: JSON.stringify( doc ),
                //data: object,
                contentType: "application/json"
            }).done(function( msg ) {
                console.log(msg);
            });
        })
    })
}



function keyword(string) {
    var notgood = ['','and','I','the','be','am','is','are'];
    var ary = string.split(" ");
    ary = ary.filter(x=>{
        "use strict";
        return notgood.indexOf(x)==-1;
    })
    ary = ary.map(x=>{
        if((x[x.length-1]==",")||(x[x.length-1]==".")||(x[x.length-1]=="!")){
            return x.slice(0,-1);
        }else{
            return x;
        }
    })
    console.log("ary",ary)
    if(ary.length<5){
        return ary;
    }
    var dict = {};
    ary.forEach(x=>{
        "use strict";
        if(dict[x]==undefined){
            dict[x] = 1;
        }else {
            dict[x]++;
        }
    });
    var lst=[];
    console.log("dict",dict);
    if(Object.keys(dict).length <5){
        return lst;
    }
    for(var i=0;i<5;i++){
        var highA=Object.keys(dict).reduce(function(a, b){ return dict[a] > dict[b] ? a : b });
        delete dict[highA];
        if(notgood.indexOf(highA)==-1){
            lst.push(highA)
        }
    }

    return lst;
}



