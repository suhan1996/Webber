var getCurrentTab = function(callback) {
  chrome.tabs.getSelected(null,function(tab) {
    console.log(tab);
    callback(null, tab);
  });
};

var extractDomain = function (url) {
    var domain,domain1;
    //find & remove protocol (http, ftp, etc.) and get domain
    if (url.indexOf("://") > -1) {
        domain1 = url.split(/.| /);
        domain = (domain1.slice(2,-1));
        console.log(domain)
        domain = domain.join();
    }
    else {
        domain1 = url.split(/.| /);
        domain = (domain1).join();

    }

    //find & remove port number
    //domain = domain.split(':')[0];

    return domain;
}
chrome.browserAction.onClicked.addListener(function(tab) {
    chrome.tabs.executeScript({
        //code: 'var btn1 = document.createElement("button");btn1.innerHTML = "butttn";document.body.appendChild(btn1);'
        code:'document.getElementById("mySidenav").style.width = "250px";'
    });
    go();

    // chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
    //     chrome.tabs.sendMessage(tabs[0].id, {
    //         greeting: "iconclicked",
    //     }, function (response) {
    //     });
    // });
});


chrome.tabs.onActivated.addListener(function() {
    "use strict";
})
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
    "use strict";
    icon();
});
chrome.tabs.onActivated.addListener(function(){


    icon();
    chrome.runtime.onMessage.addListener(
        function(request, sender, sendResponse) {
            console.log(sender.tab ?
                "from a content script:" + sender.tab.url :
                "from the extension");
            if (request.greeting == "load"){
                go();
                sendResponse({farewell: "goodbye"});
                request.greeting = "";
            }
        });
    function icon() {
        getCurrentTab(function (err, tab) {
            var url = "", ttl = "";

            url = "http://chromewebber.herokuapp.com/" + ((tab.title).split(" ")).join('-');
            $.getJSON(url, function (data) {
                if (url != "http://chromewebber.herokuapp.com/") {
                    // alert(url);
                    //  alert("huh");

                    var items = [];
                    $.each(data, function (key, val) {
                        var today = (new Date()).toLocaleString();
                        var dt = (val.date).slice(0,10)==today.slice(0,10)?(val.date).slice(10):(val.date).slice(0,9);

                        items.push("<li id='" + key + "'>" +"<p class='datetime'>"+dt+ '<img height="15px" width="15px" class="fa-thumbs-o-up" src="https://upload.wikimedia.org/wikipedia/commons/5/56/Ei-like.svg">'+"</p>" +"<p class='oldcomments'>"+val.comment +"</p>"+"</li>");
                        console.log(val.comment);
                    });

                    var len = (items.length);
                    if (len != 0) {
                        chrome.browserAction.setBadgeBackgroundColor({color: [25, 18, 106, 255]});
                        chrome.browserAction.setBadgeText({text: len.toString()});
                    } else {
                        chrome.browserAction.setBadgeText({text: ""});
                    }

                }
            });
        });

    }
    return 0;

});
function go() {
    getCurrentTab(function (err, tab) {
        var url = "", ttl = "";

        url = "http://chromewebber.herokuapp.com/" + ((tab.title).split(" ")).join('-');
        $.getJSON(url, function (data) {
            if (url != "http://chromewebber.herokuapp.com/") {
                // alert(url);
                //  alert("huh");

                var items = [];
                $.each(data, function (key, val) {
                    var today = (new Date()).toLocaleString();
                    var dt = (val.date).slice(0,10)==today.slice(0,10)?(val.date).slice(11):(val.date).slice(0,9);
                    items.push("<li >" +"<p class='datetime'>"+dt+ "</p>" +"<p class='oldcomments'>"+val.comment +"</p>"+"</li>");
                    //items.push("<li >" +"<p class='datetime'>"+dt+ '<img id=' +"yeslike"+ val._id + ' height="15px" width="15px" class="fa-thumbs-o-up" src="https://upload.wikimedia.org/wikipedia/commons/5/56/Ei-like.svg">'+'<span>'+val._id+'</span>'+'<img id=' +"dislike"+ val._id + 'height="15px" width="15px" class="fa-thumbs-o-down" src="https://upload.wikimedia.org/wikipedia/commons/5/56/Ei-like.svg">'+"</p>" +"<p class='oldcomments'>"+val.comment +"</p>"+"</li>");
                    console.log(val.comment);
                });

                var len = (items.length);
                if (len != 0) {
                    chrome.browserAction.setBadgeBackgroundColor({color: [25, 18, 106, 255]});
                    chrome.browserAction.setBadgeText({text: len.toString()});
                } else {
                    chrome.browserAction.setBadgeText({text: ""});
                }


                chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
                    // getCurrentTab(function(err, tab) {
                    var doc = {
                        url: tab.url,
                        date: (new Date()).toLocaleString(),
                        title: ((tab.title).split(" ")).join('-'),
                        comment: ""
                    }


                    chrome.tabs.sendMessage(tabs[0].id, {
                        greeting: "hello",
                        items: items.reverse(),
                        doc: doc
                    }, function (response) {
                        return 0;
                    });
                    return 0;
                });
            }
        });
    });
    return 0;
}
